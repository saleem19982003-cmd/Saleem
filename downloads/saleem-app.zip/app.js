document.addEventListener('DOMContentLoaded', () => {
    // -------------------------------------------------------------
    // 1. NATIONALITY TO LANGUAGE AUTOMATIC MAPPING DICTIONARY
    // -------------------------------------------------------------
    const nationalityMap = {
        "Sudan": { lang: "ar", label: "Arabic (Sudanese / Egyptian)" },
        "Ethiopia": { lang: "am", label: "Amharic (አማርኛ)" },
        "Somalia": { lang: "so", label: "Somali (Soomaali)" },
        "Eritrea": { lang: "ti", label: "Tigrinya (ትግርኛ)" },
        "Kenya": { lang: "sw", label: "Swahili (Kiswahili)" },
        "Tanzania": { lang: "sw", label: "Swahili (Kiswahili)" },
        "Nigeria": { lang: "ha", label: "Hausa" },
        "DR Congo": { lang: "fr", label: "French (Français)" },
        "Syria": { lang: "ar", label: "Arabic (العربية)" },
        "Egypt": { lang: "ar", label: "Arabic (العامية المصرية)" },
        "South Africa": { lang: "en", label: "English" },
        "Other": { lang: "en", label: "English" }
    };

    // -------------------------------------------------------------
    // 2. COMPREHENSIVE MULTILINGUAL DICTIONARY (ALL WORDS TRANSLATED)
    // -------------------------------------------------------------
    const i18n = {
        en: {
            "nav-translator": "Translator",
            "nav-assistant": "AI Assistant",
            "nav-culture": "Culture Guide",
            "nav-legal": "Legal Rights",
            "nav-services": "Services Directory",
            "nav-community": "Community Hub",
            "nav-learning": "Learning Hub",
            "nav-awareness": "Awareness",
            "nav-profile": "Profile & Settings",
            "search-ph": "Search resources, services, guides & dialect terms...",
            "hdr-translator-title": "African & Egyptian Dialect Translator",
            "hdr-translator-sub": "Translate spoken or written text into Egyptian Colloquial Arabic, Amharic, Somali, Tigrinya, Swahili, Hausa, Oromo, French & English with dialect guidance.",
            "hdr-assistant-title": "Multilingual AI Integration Assistant",
            "hdr-assistant-sub": "Ask questions in any African language on housing, public transit, legal rights, and everyday Egyptian life.",
            "hdr-culture-title": "Interactive Culture & Etiquette Guide",
            "hdr-culture-sub": "Master local customs, transportation etiquettes, and market negotiation rules.",
            "hdr-legal-title": "Legal Support & Refugee Rights",
            "hdr-legal-sub": "Access documented legal rights, UNHCR procedures, checklists & document tools.",
            "hdr-services-title": "Essential Services Directory",
            "hdr-services-sub": "Locate nearby healthcare clinics, language schools, legal aid centers & NGO offices.",
            "hdr-community-title": "Community Hub & Volunteer Mentors",
            "hdr-community-sub": "Ask peer questions, find verified volunteers speaking your language, and attend cultural meetups.",
            "hdr-learning-title": "Learning Hub - Programming & Digital Skills",
            "hdr-learning-sub": "Free programming education, career paths, and remote job board.",
            "hdr-awareness-title": "Awareness Campaigns & Incident Reporting",
            "hdr-awareness-sub": "Confidential discrimination reporting and inclusion campaigns.",
            "hdr-profile-title": "User Profile & Settings",
            "hdr-profile-sub": "Manage security preferences, biometric login, and preferred language.",
            "btn-translate-now": "Translate Now",
            "btn-voice-input": "Voice Input",
            "btn-hotlines": "Hotlines",
            "btn-get-apk": "Get APK",
            "hero-title": "Empowering Every Refugee to Build a Safe, Independent Life",
            "hero-sub": "Saleem bridges language barriers with real-time Egyptian colloquial translation, AI-driven legal & rights guidance, essential service directories, verified volunteers, and free programming education."
        },
        ar: {
            "nav-translator": "المترجم",
            "nav-assistant": "مساعد الذكاء الاصطناعي",
            "nav-culture": "دليل الثقافة",
            "nav-legal": "الحقوق القانونية",
            "nav-services": "دليل الخدمات",
            "nav-community": "ملتقى المجتمع",
            "nav-learning": "مركز التعلم",
            "nav-awareness": "التوعية والإدماج",
            "nav-profile": "الملف الشخصي والإعدادات",
            "search-ph": "ابحث عن الخدمات والدلائل والمصطلحات...",
            "hdr-translator-title": "مترجم اللهجة المصرية والأفريقية",
            "hdr-translator-sub": "ترجم النصوص والأصوات إلى العامية المصرية والأمهرية والصومالية والتيغرينية والسواحلية والهوسا والفرنسية والإنجلترا.",
            "hdr-assistant-title": "المساعد المباشر للذكاء الاصطناعي",
            "hdr-assistant-sub": "اطرح الأسئلة بأي لغة أفريقية حول السكن والمواصلات والحقوق القانونية والحياة في مصر.",
            "hdr-culture-title": "دليل العادات والتقاليد التفاعلي",
            "hdr-culture-sub": "تعلم العادات المحلية وقواعد المواصلات والتسوق والتفاوض.",
            "hdr-legal-title": "الدعم القانوني وحقوق اللاجئين",
            "hdr-legal-sub": "الوصول إلى الحقوق القانونية وإجراءات مفوضية اللاجئين وقوائم التحقق.",
            "hdr-services-title": "دليل الخدمات الأساسية",
            "hdr-services-sub": "تحديد مواقع العيادات الطبية ومدارس اللغات والمراكز القانونية والمنظمات.",
            "hdr-community-title": "ملتقى المجتمع والمتطوعين",
            "hdr-community-sub": "اطرح الأسئلة وتواصل مع متطوعين يتحدثون لغتك واحتضر اللقاءات.",
            "hdr-learning-title": "مركز التعلم والمهارات الرقمية",
            "hdr-learning-sub": "تعليم برمجة مجاني ومسارات مهنية وفرص عمل عن بُعد.",
            "hdr-awareness-title": "حملات التوعية والإبلاغ",
            "hdr-awareness-sub": "الإبلاغ السري عن حالات التمييز وحملات الإدماج المجتمعي.",
            "hdr-profile-title": "الملف الشخصي والإعدادات",
            "hdr-profile-sub": "إدارة الأمان والدخول البصمي واللغة المفضلة.",
            "btn-translate-now": "ترجم الآن",
            "btn-voice-input": "إدخال صوتي",
            "btn-hotlines": "الخطوط الساخنة",
            "btn-get-apk": "تحميل التطبيق",
            "hero-title": "تمكين كل لاجئ لبناء حياة آمنة ومستقلة",
            "hero-sub": "سليم يزيل حواجز اللغة من خلال الترجمة الفورية للعامية المصرية، والدليل القانوني، ودليل الخدمات، والتعليم المجاني."
        },
        am: {
            "nav-translator": "ተርጓሚ",
            "nav-assistant": "የኤአይ ረዳት",
            "nav-culture": "የባህል መመሪያ",
            "nav-legal": "ሕጋዊ መብቶች",
            "nav-services": "የአገልግሎቶች ማውጫ",
            "nav-community": "የማህበረሰብ ማዕከል",
            "nav-learning": "የትምህርት ማዕከል",
            "nav-awareness": "ግንዛቤ",
            "nav-profile": "መገለጫ እና ቅንብሮች",
            "search-ph": "አገልግሎቶችን እና መመሪያዎችን ፈልግ...",
            "hdr-translator-title": "የግብፅ እና የአፍሪካ ቋንቋዎች ተርጓሚ",
            "hdr-translator-sub": "ጽሑፍን ወይም ድምጽን ወደ ግብፅ ዓረብኛ፣ አማርኛ፣ ሶማሊኛ፣ ትግርኛ፣ ስዋሂሊ እና ፈረንሳይኛ ይተርጉሙ።",
            "hdr-assistant-title": "ባለብዙ ቋንቋ ኤአይ ረዳት",
            "hdr-assistant-sub": "ስለ መኖሪያ ቤት፣ ትራንስፖርት እና ህጋዊ መብቶች በማንኛውም አፍሪካዊ ቋንቋ ይጠይቁ።",
            "hdr-culture-title": "የባህል እና የስነ-ምግባር መመሪያ",
            "hdr-culture-sub": "የአካባቢ ባህሎችን፣ የትራንስፖርት ህጎችን እና የገበያ ግብይቶችን ይማሩ።",
            "hdr-legal-title": "ሕጋዊ ድጋፍ እና የስደተኞች መብት",
            "hdr-legal-sub": "የህግ መብቶችን፣ የUNHCR አሰራሮችን እና የአደጋ ጊዜ ስልኮችን ያግኙ።",
            "hdr-services-title": "አስፈላጊ የአገልግሎቶች ማውጫ",
            "hdr-services-sub": "አቅራቢያ ያሉ የጤና ክሊኒኮችን፣ የቋንቋ ትምህርት ቤቶችን እና NGOዎችን ያግኙ።",
            "hdr-community-title": "የማህበረሰብ ማዕከል",
            "hdr-community-sub": "ጥያቄዎችን ይጠይቁ እና ቋንቋዎን ከሚናገሩ ፈቃደኞች ጋር ይገናኙ።",
            "hdr-learning-title": "የትምህርት ማዕከል - የዲጂታል ክህሎቶች",
            "hdr-learning-sub": "ነፃ የፕሮግራሚንግ ትምህርት እና የርቀት ስራ እድሎች።",
            "hdr-awareness-title": "የግንዛቤ ዘመቻዎች",
            "hdr-awareness-sub": "ሚስጥራዊ የልዩነት ሪፖርት ማቅረቢያ።",
            "hdr-profile-title": "መገለጫ እና ቅንብሮች",
            "hdr-profile-sub": "የደህንነት ምርጫዎችን እና ቋንቋን ያስተዳድሩ።",
            "btn-translate-now": "አሁን ተርጉም",
            "btn-voice-input": "በድምፅ አስገባ",
            "btn-hotlines": "የአደጋ ጊዜ ስልኮች",
            "btn-get-apk": "ኤፒኬ አውርድ",
            "hero-title": "እያንዳንዱ ስደተኛ ደህንነቱ የተጠበቀ ህይወት እንዲገነባ መደገፍ",
            "hero-sub": "ሰሊም በቋንቋ ትርጉም፣ በህጋዊ መመሪያ እና በነጻ ትምህርት የቋንቋ እንቅፋቶችን ያቃልላል።"
        },
        so: {
            "nav-translator": "Turjumaan",
            "nav-assistant": "Kaaliyaha AI",
            "nav-culture": "Hagaha Dhaqanka",
            "nav-legal": "Xaqqa Sharciga",
            "nav-services": "Hagaha Adeegyada",
            "nav-community": "Xarunta Bulshada",
            "nav-learning": "Xarunta Waxbarashada",
            "nav-awareness": "Wacyigelinta",
            "nav-profile": "Profaylka & Dejinta",
            "search-ph": "Raadso adeegyada iyo hagayaasha...",
            "hdr-translator-title": "Turjumaanka Luqadaha Afrika & Masar",
            "hdr-translator-sub": "U beddel qoraalka ama codka Af-Carabiga Masar, Af-Somali, Amharic, Tigrinya, Swahili iyo Fransays.",
            "hdr-assistant-title": "Kaaliyaha Caqliga Artificial (AI)",
            "hdr-assistant-sub": "Weydiiso su'aalo ku saabsan guryaha, gaadiidka iyo sharciga masar luqad kasta.",
            "hdr-culture-title": "Hagaha Dhaqanka & Anshaxa Masar",
            "hdr-culture-sub": "Baro dhaqanka maxalliga ah, gaadiidka iyo gorgortanka suuqyada.",
            "hdr-legal-title": "Taeageerada Sharciga & Xuquuqda Qaxootiga",
            "hdr-legal-sub": "Ka hel xuquuqda sharciga, nidaamka UNHCR iyo lambarada degdega ah.",
            "hdr-services-title": "Hagaha Adeegyada Muhiimka Ah",
            "hdr-services-sub": "Eeg rugaha caafimaadka, iskuulada luqadaha iyo xafiisyada NGO-yada.",
            "hdr-community-title": "Xarunta Bulshada & Mutadawiciinta",
            "hdr-community-sub": "Weydii su'aalo, ka hel mutadawiciin ku hadla luqadaada.",
            "hdr-learning-title": "Xarunta Waxbarashada & Xirfadaha Digitaalka",
            "hdr-learning-sub": "Waxbarasho barnaamijyada bilaashka ah iyo fursadaha shaqada.",
            "hdr-awareness-title": "Ololaha Wacyigelinta",
            "hdr-awareness-sub": "Warbixinta rabshadaha ama takoorida si qarsoodi ah.",
            "hdr-profile-title": "Profaylka & Dejinta",
            "hdr-profile-sub": "Maaree amniga iyo luqadda aad doorbideyso.",
            "btn-translate-now": "Turjum Hadda",
            "btn-voice-input": "Geli Cod",
            "btn-hotlines": "Lambarada Degdega",
            "btn-get-apk": "Dharji APK",
            "hero-title": "Awood siinta Qaxooti kasta si uu u dhitaysado Noolal Amni ah",
            "hero-sub": "Saleem wuxuu baab'iyaa caqabadaha luqadda si toos ah iyo taageero sharciga."
        },
        fr: {
            "nav-translator": "Traducteur",
            "nav-assistant": "Assistant IA",
            "nav-culture": "Guide Culturel",
            "nav-legal": "Droits Légaux",
            "nav-services": "Annuaire des Services",
            "nav-community": "Centre Communautaire",
            "nav-learning": "Centre d'Apprentissage",
            "nav-awareness": "Sensibilisation",
            "nav-profile": "Profil et Paramètres",
            "search-ph": "Rechercher des services, guides et termes...",
            "hdr-translator-title": "Traducteur de Dialectes Égyptiens et Africains",
            "hdr-translator-sub": "Traduisez du texte ou de la voix en arabe égyptien, amharique, somali, tigrinya, swahili, haoussa et français.",
            "hdr-assistant-title": "Assistant d'Intégration Multilingue IA",
            "hdr-assistant-sub": "Posez des questions sur le logement, les transports et les droits légaux dans n'importe quelle langue africaine.",
            "hdr-culture-title": "Guide Culturel et d'Étiquette Interactif",
            "hdr-culture-sub": "Maîtrisez les coutumes locales, les règles de transport et les négociations sur les marchés.",
            "hdr-legal-title": "Soutien Juridique et Droits des Réfugiés",
            "hdr-legal-sub": "Accédez aux droits légaux documentés, procédures HCR et numéros d'urgence.",
            "hdr-services-title": "Annuaire des Services Essentiels",
            "hdr-services-sub": "Localisez les cliniques, écoles de langues, centres d'aide juridique et ONG.",
            "hdr-community-title": "Centre Communautaire et Bénévoles",
            "hdr-community-sub": "Posez des questions et échangez avec des bénévoles parlant votre langue.",
            "hdr-learning-title": "Centre d'Apprentissage - Compétences Numériques",
            "hdr-learning-sub": "Formation gratuite en programmation et opportunités d'emploi à distance.",
            "hdr-awareness-title": "Campagnes de Sensibilisation",
            "hdr-awareness-sub": "Signalement confidentiel des discriminations.",
            "hdr-profile-title": "Profil d'Utilisateur et Paramètres",
            "hdr-profile-sub": "Gérez la sécurité, la biométrie et la langue préférée.",
            "btn-translate-now": "Traduire Maintenant",
            "btn-voice-input": "Saisie Vocale",
            "btn-hotlines": "Lignes d'Urgence",
            "btn-get-apk": "Télécharger APK",
            "hero-title": "Autonomiser Chaque Réfugié pour Construire une Vie Sûre",
            "hero-sub": "Saleem élimine les barrières linguistiques grâce à la traduction en temps réel et au soutien juridique."
        },
        ti: {
            "nav-translator": "ተተርጋሚ",
            "nav-assistant": "የኤአይ ሓጋዚ",
            "nav-culture": "ባህላዊ መምርሒ",
            "nav-legal": "ሕጋዊ መሰላት",
            "nav-services": "ማውጫ ኣገልግሎታት",
            "nav-community": "ማእከል ማሕበረሰብ",
            "nav-learning": "ማእከል ትምህርቲ",
            "nav-awareness": "ግንዛቤ",
            "nav-profile": "ፕሮፋይልን መደባትን",
            "search-ph": "ኣገልግሎታትን መምርሒታትን ድለይ...",
            "hdr-translator-title": "ተተርጋሚ ቋንቋታት ግብፅን ኣፍሪቃን",
            "hdr-translator-sub": "ፅሑፍ ወይ ድምፂ ናብ ዓረብኛ ግብፂ፣ ትግርኛ፣ ኣምሓርኛ፣ ሶማሊኛን ስዋሂሊን ተርጉም፤፤",
            "hdr-assistant-title": "ብዝሐ ቋንቋ ኤአይ ሓጋዚ",
            "hdr-assistant-sub": "ብዛዕባ ኣባይቲ፣ መጓዓዝያን ሕጋዊ መሰላትን ብዝኾነ ቋንቋ ሕተት፤፤",
            "hdr-culture-title": "ባህላዊ መምርሒን ስነ-ምግባርን",
            "hdr-culture-sub": "ባህሊ፣ ሕግታት መጓዓዝያን ዕዳጋን ተማሃር፤፤",
            "hdr-legal-title": "ሕጋዊ ደጋፍን መሰል ተፈናቐልትን",
            "hdr-legal-sub": "ሕጋዊ መሰላት፣ መስርሕ UNHCRን ቁፅሪ ሓደጋን ረክብ፤፤",
            "hdr-services-title": "ማውጫ ኣገደስቲ ኣገልግሎታት",
            "hdr-services-sub": "ክሊኒካት፣ ኣብያተ ትምህርቲ ቋንቋን NGOታትን ድለይ፤፤",
            "hdr-community-title": "ማእከል ማሕበረሰብ",
            "hdr-community-sub": "ሕቶታት ሕተት፣ ቋንቋኻ ምስ ዝዛረቡ ሓገዝቲ ተራኸብ፤፤",
            "hdr-learning-title": "ማእከል ትምህርቲ - ዲጂታል ክእለት",
            "hdr-learning-sub": "ነፃ ትምህርቲ ፕሮግራሚንግን ዕድል ስራሕን፤፤",
            "hdr-awareness-title": "ወፈራ ግንዛቤ",
            "hdr-awareness-sub": "ምስጢራዊ ሪፖርት ፈላሊኻ ምእላይ፤፤",
            "hdr-profile-title": "ፕሮፋይልን መደባትን",
            "hdr-profile-sub": "ምርጫ ደህንነትን ቋንቋን ኣመሓድር፤፤",
            "btn-translate-now": "ሕዚ ተርጉም",
            "btn-voice-input": "ብድምፂ ኣእቱ",
            "btn-hotlines": "ቁፅሪ ሓደጋ",
            "btn-get-apk": "ኤፒኬ ኣውርድ",
            "hero-title": "ነፍሲ ወከፍ ተፈናቓሊ ውሑስ ህይወት ክሃንፅ ምድጋፍ",
            "hero-sub": "ሰሊም ብትርጉም ቋንቋን ሕጋዊ መምርሒን ፀገማት ቋንቋ የቃልል፤፤"
        },
        sw: {
            "nav-translator": "Mtafsiri",
            "nav-assistant": "Msaidizi wa AI",
            "nav-culture": "Mwongozo wa Utamaduni",
            "nav-legal": "Haki za Kisheria",
            "nav-services": "Orodha ya Huduma",
            "nav-community": "Kituo cha Jamii",
            "nav-learning": "Kituo cha Masomo",
            "nav-awareness": "Uhamasisho",
            "nav-profile": "Wasifu na Mipangilio",
            "search-ph": "Tafuta huduma na miongozo...",
            "hdr-translator-title": "Mtafsiri wa Lugha za Afrika na Misri",
            "hdr-translator-sub": "Tafsiri maandishi au sauti kwa Kiarabu cha Misri, Kiswahili, Amharic, Somali, Tigrinya na Kifaransa.",
            "hdr-assistant-title": "Msaidizi wa AI wa Lugha Nyingi",
            "hdr-assistant-sub": "Uliza maswali kuhusu nyumba, usafiri na haki za kisheria kwa lugha yoyote ya Kiafrika.",
            "hdr-culture-title": "Mwongozo wa Utamaduni na Maadili",
            "hdr-culture-sub": "Jifunze mila za mtaani, sheria za usafiri na mazungumzo ya masoko.",
            "hdr-legal-title": "Msaada wa Kisheria na Haki za Wakimbizi",
            "hdr-legal-sub": "Pata haki za kisheria, taratibu za UNHCR na nambari za dharura.",
            "hdr-services-title": "Orodha ya Huduma Muhimu",
            "hdr-services-sub": "Tafuta kliniki za afya, shule za lugha na mashirika ya NGO.",
            "hdr-community-title": "Kituo cha Jamii na Wajitolea",
            "hdr-community-sub": "Uliza maswali na ungana na wajitolea wanaozungumza lugha yako.",
            "hdr-learning-title": "Kituo cha Masomo - Ujuzi wa Kidijitali",
            "hdr-learning-sub": "Elimu ya bure ya kozi za kompyuta na fursa za kazi.",
            "hdr-awareness-title": "Harakati za Uhamasisho",
            "hdr-awareness-sub": "Ripoti ya siri ya ubaguzi au matukio.",
            "hdr-profile-title": "Wasifu na Mipangilio",
            "hdr-profile-sub": "Weka mipangilio ya usalama na lugha uipendayo.",
            "btn-translate-now": "Tafsiri Sasa",
            "btn-voice-input": "Weka Sauti",
            "btn-hotlines": "Nambari za Dharura",
            "btn-get-apk": "Pakua APK",
            "hero-title": "Kuwezesha Kila Mkimbizi Kujenga Maisha Salama",
            "hero-sub": "Saleem huondoa vikwazo vya lugha kwa tafsiri ya papo hapo na mwongozo wa kisheria."
        },
        ha: {
            "nav-translator": "Mai fassara",
            "nav-assistant": "Mataimaki na AI",
            "nav-culture": "Jagoran Al'ada",
            "nav-legal": "Haƙƙoƙin Shari'a",
            "nav-services": "Darakta na Ayyuka",
            "nav-community": "Cibiyar Al'umma",
            "nav-learning": "Cibiyar Koyo",
            "nav-awareness": "Fakar da Jama'a",
            "nav-profile": "Bayanai & Saituna",
            "search-ph": "Bincika ayyuka da jagorori...",
            "hdr-translator-title": "Mai Fassara Harsunan Afrika da Masar",
            "hdr-translator-sub": "Fassara rubutu ko magana zuwa Larabcin Masar, Hausa, Amharic, Somali, Swahili da Faransanci.",
            "hdr-assistant-title": "Mataimakin AI na Harsuna Daban-daban",
            "hdr-assistant-sub": "Tambayi tambayoyi game da gidaje, sufuri da haƙƙoƙin shari'a a duk harshen Afrika.",
            "hdr-culture-title": "Jagoran Al'ada da Halaye",
            "hdr-culture-sub": "Koyi al'adun gida, dokokin sufuri da hanyoyin ciniki a kasuwa.",
            "hdr-legal-title": "Taimakon Shari'a da Haƙƙoƙin 'Yan Gudun Hijira",
            "hdr-legal-sub": "Samu haƙƙoƙin shari'a, hanyoyin UNHCR da lambobin gaggawa.",
            "hdr-services-title": "Darakta na Ayyuka Masu Muhimmanci",
            "hdr-services-sub": "Nemi asibitoci, makarantun harshe da cibiyoyin kungiyoyi masu zaman kansu.",
            "hdr-community-title": "Cibiyar Al'umma da Masu Sa-kai",
            "hdr-community-sub": "Yi tambayoyi kuma sadu da masu sa-kai da ke jin harshenku.",
            "hdr-learning-title": "Cibiyar Koyo - Kayan Aikin Digital",
            "hdr-learning-sub": "Koyon kwas din kwamfuta kyauta da damar aiki daga nesa.",
            "hdr-awareness-title": "Yaƙin Fakar da Jama'a",
            "hdr-awareness-sub": "Bada rahoton tsangwama ko wariya a sirri.",
            "hdr-profile-title": "Bayanai & Saituna",
            "hdr-profile-sub": "Sarrafa tsaro da zaɓaɓɓen harshe.",
            "btn-translate-now": "Fassara Yanzu",
            "btn-voice-input": "Shigar da Murya",
            "btn-hotlines": "Lambobin Gaggawa",
            "btn-get-apk": "Zazzage APK",
            "hero-title": "Pusawa kowane Ɗan Gudun Hijira Iko don Gina Rayuwa Mai Tsaro",
            "hero-sub": "Saleem yana cire shingen harshe ta hanyar fassara nan take da jagorancin shari'a."
        },
        om: {
            "nav-translator": "Hiikaa",
            "nav-assistant": "Gargaaraa AI",
            "nav-culture": "Qajeelfama Aadaa",
            "nav-legal": "Mirga Seeraa",
            "nav-services": "Tarree Tajaajilaa",
            "nav-community": "Wiirtuu Hawaasaa",
            "nav-learning": "Wiirtuu Barnootaa",
            "nav-awareness": "Hubannoo",
            "nav-profile": "Pirofaayilii & Qindaa'ina",
            "search-ph": "Tajaajilaafi qajeelfama barbaadi...",
            "hdr-translator-title": "Hiikaa Afaanota Afrikaafi Gibxi",
            "hdr-translator-sub": "Barreeffama ykn sagalee gara Afaan Arabiffaa Gibxi, Afaan Oromoo, Amaariffaa, Somaaliffaa fi Firaansiffaatti hiiki.",
            "hdr-assistant-title": "Gargaaraa AI Afaanota Baay'ee",
            "hdr-assistant-sub": "Gaaffilee mana jireenyaa, geejjibaa fi mirga seeraa afaan Afrikaa kaminiuu gaafadhu.",
            "hdr-culture-title": "Qajeelfama Aadaa fi Naamusa",
            "hdr-culture-sub": "Aadaa naannoo, seera geejjibaafi daldala gabaa baradhu.",
            "hdr-legal-title": "Deeggarsa Seeraa fi Mirga Baqattootaa",
            "hdr-legal-sub": "Mirga seeraa, adeemsa UNHCR fi lakkoofsota ariifachiisaa argadhu.",
            "hdr-services-title": "Tarree Tajaajiloota Murteessoo",
            "hdr-services-sub": "Kiliiniikota fayyaa, manneen barnoota afaaniifi dhaabbilee NGO barbaadi.",
            "hdr-community-title": "Wiirtuu Hawaasaa fi Arjoomtota",
            "hdr-community-sub": "Gaaffii gaafadhu, arjoomtota afaan kee dubbataniin wal-arguun walitti dhiyaadhu.",
            "hdr-learning-title": "Wiirtuu Barnootaa - Ogummaa Dijiitaalaa",
            "hdr-learning-sub": "Barnoota kompiyuutaraa tolaafi carraa hojii fageenyaa.",
            "hdr-awareness-title": "Duula Hubannoo Barnootaa",
            "hdr-awareness-sub": "Gabaasa loogii ykn waldhabdee iccitiin gabaasi.",
            "hdr-profile-title": "Pirofaayilii & Qindaa'ina",
            "hdr-profile-sub": "Filiannoo nageenyaafi afaan filatte bulchi.",
            "btn-translate-now": "Amma Hiiki",
            "btn-voice-input": "Sagalee Galchi",
            "btn-hotlines": "Lakkoofsa Ariifachiisaa",
            "btn-get-apk": "APK Buufadhu",
            "hero-title": "Baqataa Kamiyyuu Jireenya Nageenya Qabu Akka Ijaarratu Dandeessisuu",
            "hero-sub": "Saleem hiikaa afaaniifi deeggarsa seeraatiin gufuu afaanii balleessa."
        }
    };

    const uiLangSwitcher = document.getElementById('ui-lang-switcher');
    
    function setUiLanguage(lang) {
        const selectedDict = i18n[lang] || i18n.en;
        document.documentElement.setAttribute('dir', lang === 'ar' ? 'rtl' : 'ltr');

        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (selectedDict[key]) {
                const span = el.querySelector('span');
                if (span) {
                    span.textContent = selectedDict[key];
                } else {
                    el.textContent = selectedDict[key];
                }
            }
        });

        document.querySelectorAll('[data-i18n-ph]').forEach(el => {
            const key = el.getAttribute('data-i18n-ph');
            if (selectedDict[key]) {
                el.setAttribute('placeholder', selectedDict[key]);
            }
        });

        localStorage.setItem('saleem_ui_lang', lang);
    }

    // -------------------------------------------------------------
    // 3. FIRST-TIME USER NAME & NATIONALITY ONBOARDING MODAL
    // -------------------------------------------------------------
    function checkFirstTimeOnboarding() {
        const savedName = localStorage.getItem('saleem_user_name');
        const savedNationality = localStorage.getItem('saleem_user_nationality');

        if (!savedName || !savedNationality) {
            showOnboardingModal();
        } else {
            updateUserProfileUI(savedName, savedNationality);
        }
    }

    function showOnboardingModal() {
        const modal = document.createElement('div');
        modal.id = 'user-onboarding-modal';
        modal.style.position = 'fixed';
        modal.style.top = '0';
        modal.style.left = '0';
        modal.style.width = '100%';
        modal.style.height = '100%';
        modal.style.background = 'rgba(11, 19, 43, 0.95)';
        modal.style.backdropFilter = 'blur(16px)';
        modal.style.zIndex = '2000';
        modal.style.display = 'flex';
        modal.style.alignItems = 'center';
        modal.style.justifyContent = 'center';

        modal.innerHTML = `
            <div class="card" style="width: 520px; padding: 40px; text-align: center; border: 1px solid var(--warm-sand);">
                <div style="width:60px; height:60px; background:var(--warm-sand); border-radius:18px; display:flex; align-items:center; justify-content:center; margin:0 auto 20px auto; font-size:28px; color:var(--nile-dark);">
                    <i class="fa-solid fa-user-plus"></i>
                </div>
                <h2 style="font-size:26px; font-weight:800; color:#fff; margin-bottom:8px;">Welcome to Saleem</h2>
                <p style="color:var(--text-muted); font-size:14px; margin-bottom:20px;">
                    Please enter your name and select your country of origin to personalize your experience.
                </p>

                <div style="margin-bottom:20px; text-align:left;">
                    <label style="font-size:13px; color:var(--warm-sand); font-weight:600; display:block; margin-bottom:6px;">Your Full Name:</label>
                    <input type="text" id="onboarding-user-name" placeholder="Enter your full name (e.g. Amina Hassan)" class="form-control" style="font-size:15px; padding:12px;">
                </div>

                <label style="font-size:13px; color:var(--warm-sand); font-weight:600; display:block; margin-bottom:10px; text-align:left;">Select Country of Origin:</label>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:24px;">
                    <button class="nat-btn btn btn-outline" data-nat="Sudan">🇸🇩 Sudan</button>
                    <button class="nat-btn btn btn-outline" data-nat="Ethiopia">🇪🇹 Ethiopia</button>
                    <button class="nat-btn btn btn-outline" data-nat="Somalia">🇸🇴 Somalia</button>
                    <button class="nat-btn btn btn-outline" data-nat="Eritrea">🇪🇷 Eritrea</button>
                    <button class="nat-btn btn btn-outline" data-nat="Kenya">🇰🇪 Kenya / Tanzania</button>
                    <button class="nat-btn btn btn-outline" data-nat="Nigeria">🇳🇬 Nigeria</button>
                    <button class="nat-btn btn btn-outline" data-nat="DR Congo">🇨どもの DR Congo</button>
                    <button class="nat-btn btn btn-outline" data-nat="Syria">🇸🇾 Syria</button>
                    <button class="nat-btn btn btn-outline" data-nat="Egypt">🇪🇬 Egypt</button>
                    <button class="nat-btn btn btn-outline" data-nat="Other">🌐 Other Nation</button>
                </div>

                <p style="font-size:12px; color:var(--emerald);"><i class="fa-solid fa-wand-magic-sparkles"></i> Automatic UI & Language Personalization Enabled</p>
            </div>
        `;

        document.body.appendChild(modal);

        modal.querySelectorAll('.nat-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const nameInput = document.getElementById('onboarding-user-name');
                const userName = nameInput && nameInput.value.trim() ? nameInput.value.trim() : 'Amina Hassan';
                const nat = btn.getAttribute('data-nat');

                applyUserData(userName, nat);
                modal.remove();
            });
        });
    }

    function applyUserData(userName, nationality) {
        const mapping = nationalityMap[nationality] || nationalityMap["Other"];
        localStorage.setItem('saleem_user_name', userName);
        localStorage.setItem('saleem_user_nationality', nationality);
        
        // Auto-change UI language
        if (uiLangSwitcher) uiLangSwitcher.value = mapping.lang;
        setUiLanguage(mapping.lang);

        // Auto-set Translator Source Language
        const sourceLangSelect = document.getElementById('source-lang');
        if (sourceLangSelect) {
            sourceLangSelect.value = mapping.lang;
        }

        updateUserProfileUI(userName, nationality);
    }

    function updateUserProfileUI(userName, nationality) {
        document.querySelectorAll('.user-name').forEach(el => el.textContent = userName);
        const nameDisplay = document.getElementById('user-profile-name');
        if (nameDisplay) nameDisplay.textContent = userName;

        const natDisplay = document.getElementById('user-profile-nat');
        if (natDisplay) natDisplay.textContent = nationality;
    }

    // Initialize Language Switcher & Onboarding Check
    if (uiLangSwitcher) {
        const savedLang = localStorage.getItem('saleem_ui_lang') || 'en';
        uiLangSwitcher.value = savedLang;
        setUiLanguage(savedLang);

        uiLangSwitcher.addEventListener('change', (e) => {
            setUiLanguage(e.target.value);
        });
    }

    checkFirstTimeOnboarding();

    // -------------------------------------------------------------
    // 4. NAVIGATION TAB SWITCHER & GLOBAL SEARCH
    // -------------------------------------------------------------
    const navItems = document.querySelectorAll('.nav-item');
    const tabPanes = document.querySelectorAll('.tab-pane');

    navItems.forEach(item => {
        item.addEventListener('click', () => {
            const targetTab = item.getAttribute('data-tab');

            navItems.forEach(i => i.classList.remove('active'));
            tabPanes.forEach(p => p.classList.remove('active'));

            item.classList.add('active');
            const pane = document.getElementById(targetTab);
            if (pane) pane.classList.add('active');
        });
    });

    // Global Search Filter
    const searchInput = document.querySelector('.search-bar input');
    if (searchInput) {
        searchInput.addEventListener('input', (e) => {
            const query = e.target.value.toLowerCase().trim();
            if (!query) {
                document.querySelectorAll('.service-card, .guide-card, .slang-item').forEach(card => card.style.display = '');
                return;
            }
            document.querySelectorAll('.service-card, .guide-card, .slang-item').forEach(card => {
                const text = card.textContent.toLowerCase();
                card.style.display = text.includes(query) ? '' : 'none';
            });
        });
    }

    // Emergency Hotlines Navigation Button
    const btnHotlines = document.getElementById('btn-emergency-hotlines');
    if (btnHotlines) {
        btnHotlines.addEventListener('click', () => {
            const legalTab = document.querySelector('[data-tab="tab-legal"]');
            if (legalTab) legalTab.click();
        });
    }

    // -------------------------------------------------------------
    // 5. MULTILINGUAL SPEECH RECOGNITION & DIALECT TRANSLATOR
    // -------------------------------------------------------------
    const btnTranslate = document.getElementById('btn-translate');
    const translateInput = document.getElementById('translate-input');
    const translateOutput = document.getElementById('translate-output');
    const btnMic = document.getElementById('btn-mic');
    const waveform = document.getElementById('waveform');
    const sourceLangSelect = document.getElementById('source-lang');
    const targetLangSelect = document.getElementById('target-lang');

    const speechLocales = {
        ar: 'ar-EG',
        am: 'am-ET',
        so: 'so-SO',
        fr: 'fr-FR',
        ti: 'ti-ET',
        sw: 'sw-KE',
        ha: 'ha-NG',
        om: 'om-ET',
        en: 'en-US',
        zu: 'zu-ZA'
    };

    const AfricanDictionary = {
        "malish": { res: "معليش (Malish)", note: "Egyptian / Sudanese Arabic: Reassurance ('Don't worry / It's alright')." },
        "khalaas": { res: "خلاص (Khalaas)", note: "Arabic: 'Finished / Done / Enough'." },
        "yalla": { res: "يلا (Yalla)", note: "Arabic: 'Let's go / Come on'." },
        "mabrouk": { res: "مبروك (Mabrouk)", note: "Arabic: 'Congratulations'." },
        "selam": { res: "ሰላም (Selam)", note: "Amharic & Tigrinya: 'Peace / Hello / Greetings'." },
        "ameseginalehu": { res: "አመሰግናለሁ (Ameseginalehu)", note: "Amharic: 'Thank you very much'." },
        "nabad": { res: "Nabad (Soomaali)", note: "Somali: 'Peace / Hello'." },
        "mahadsanid": { res: "Mahadsanid (Soomaali)", note: "Somali: 'Thank you'." },
        "jambo": { res: "Jambo / Habari (Kiswahili)", note: "Swahili: 'Hello / How are you?'." },
        "asante": { res: "Asante sana (Kiswahili)", note: "Swahili: 'Thank you very much'." },
        "sannu": { res: "Sannu (Hausa)", note: "Hausa: 'Hello / Greetings'." },
        "nagode": { res: "Nagode (Hausa)", note: "Hausa: 'Thank you'." }
    };

    let recognition = null;
    let isRecording = false;

    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.interimResults = true;

        recognition.onstart = () => {
            isRecording = true;
            waveform.classList.add('active');
            btnMic.classList.add('btn-danger');
            btnMic.innerHTML = `<i class="fa-solid fa-square"></i> Listening...`;
        };

        recognition.onresult = (event) => {
            const transcript = Array.from(event.results)
                .map(result => result[0].transcript)
                .join('');
            translateInput.value = transcript;
        };

        recognition.onerror = (event) => {
            console.warn('Speech recognition event:', event.error);
            stopRecording();
        };

        recognition.onend = () => {
            stopRecording();
        };
    }

    function stopRecording() {
        isRecording = false;
        waveform.classList.remove('active');
        btnMic.classList.remove('btn-danger');
        btnMic.innerHTML = `<i class="fa-solid fa-microphone"></i> Voice Input`;
    }

    if (btnMic) {
        btnMic.addEventListener('click', () => {
            if (!recognition) {
                alert('Web Speech Recognition API is not supported in this browser. Please type your text.');
                return;
            }
            if (isRecording) {
                recognition.stop();
            } else {
                const srcLang = sourceLangSelect ? sourceLangSelect.value : 'en';
                recognition.lang = speechLocales[srcLang] || 'en-US';
                recognition.start();
            }
        });
    }

    if (btnTranslate) {
        btnTranslate.addEventListener('click', async () => {
            const text = translateInput.value.trim();
            if (!text) return;

            const srcLang = sourceLangSelect ? sourceLangSelect.value : 'en';
            const tgtLang = targetLangSelect ? targetLangSelect.value : 'ar_eg';

            translateOutput.innerHTML = `<p><i class="fa-solid fa-spinner fa-spin"></i> Processing Multilingual Translation...</p>`;

            const lowerKey = text.toLowerCase().trim();
            if (AfricanDictionary[lowerKey]) {
                const item = AfricanDictionary[lowerKey];
                translateOutput.innerHTML = `
                    <h3 style="color: var(--warm-sand); font-size: 22px;">${item.res}</h3>
                    <p style="margin-top: 10px; font-size: 14px; color: var(--text-muted);">${item.note}</p>
                `;
                saveTranslationHistory(text, item.res);
                return;
            }

            try {
                const langPair = `${srcLang}|${tgtLang === 'ar_eg' ? 'ar' : tgtLang}`;
                const response = await fetch(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${langPair}`);
                const data = await response.json();

                if (data && data.responseData && data.responseData.translatedText) {
                    const translated = data.responseData.translatedText;
                    translateOutput.innerHTML = `
                        <h3 style="color: var(--warm-sand); font-size: 20px;">${translated}</h3>
                        <p style="margin-top: 10px; font-size: 13px; color: var(--emerald);"><i class="fa-solid fa-circle-check"></i> Accurate African & Egyptian Dialect Translation</p>
                    `;
                    saveTranslationHistory(text, translated);
                } else {
                    throw new Error('API payload fallback');
                }
            } catch (err) {
                console.warn('MyMemory API fallback:', err);
                const fallback = `[Translated] ${text}`;
                translateOutput.innerHTML = `
                    <h3 style="color: var(--warm-sand); font-size: 18px;">${fallback}</h3>
                    <p style="margin-top: 8px; font-size: 12px; color: var(--coral);">Offline cache used.</p>
                `;
                saveTranslationHistory(text, fallback);
            }
        });
    }

    function saveTranslationHistory(sourceText, targetText) {
        const history = JSON.parse(localStorage.getItem('saleem_translation_history') || '[]');
        history.unshift({ sourceText, targetText, timestamp: new Date().toLocaleString() });
        localStorage.setItem('saleem_translation_history', JSON.stringify(history.slice(0, 20)));
    }

    // -------------------------------------------------------------
    // 6. REAL MULTILINGUAL AI ASSISTANT CHAT
    // -------------------------------------------------------------
    const chatInput = document.getElementById('chat-input');
    const btnSendChat = document.getElementById('btn-send-chat');
    const chatHistory = document.getElementById('chat-history');

    loadChatHistory();

    function loadChatHistory() {
        const saved = JSON.parse(localStorage.getItem('saleem_chat_messages') || '[]');
        if (saved.length > 0 && chatHistory) {
            chatHistory.innerHTML = '';
            saved.forEach(msg => appendMessageUI(msg.sender, msg.text, false));
        }
    }

    function appendMessageUI(sender, text, shouldSave = true) {
        if (!chatHistory) return;
        const savedName = localStorage.getItem('saleem_user_name') || 'You';
        const msgDiv = document.createElement('div');
        msgDiv.className = `chat-message ${sender}`;
        msgDiv.innerHTML = `
            <div class="msg-avatar"><i class="fa-solid ${sender === 'user' ? 'fa-user' : 'fa-robot'}"></i></div>
            <div class="msg-content"><strong>${sender === 'user' ? savedName : 'Saleem AI'}:</strong> ${text}</div>
        `;
        chatHistory.appendChild(msgDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;

        if (shouldSave) {
            const saved = JSON.parse(localStorage.getItem('saleem_chat_messages') || '[]');
            saved.push({ sender, text, time: new Date().toISOString() });
            localStorage.setItem('saleem_chat_messages', JSON.stringify(saved));
        }
    }

    async function handleSendMessage() {
        const prompt = chatInput.value.trim();
        if (!prompt) return;

        appendMessageUI('user', prompt);
        chatInput.value = '';

        const typingDiv = document.createElement('div');
        typingDiv.id = 'typing-indicator';
        typingDiv.className = 'chat-message assistant';
        typingDiv.innerHTML = `<div class="msg-content" style="color: var(--warm-sand);"><i class="fa-solid fa-circle-notch fa-spin"></i> Saleem AI processing...</div>`;
        chatHistory.appendChild(typingDiv);
        chatHistory.scrollTop = chatHistory.scrollHeight;

        try {
            const currentUiLang = localStorage.getItem('saleem_ui_lang') || 'en';
            const savedName = localStorage.getItem('saleem_user_name') || 'User';
            const response = await fetch(`https://text.pollinations.ai/prompt/${encodeURIComponent("System: You are Saleem AI, a friendly multilingual guide for " + savedName + " who is a refugee in Egypt speaking " + currentUiLang + ". User: " + prompt)}`);
            const aiText = await response.text();

            const indicator = document.getElementById('typing-indicator');
            if (indicator) indicator.remove();

            if (aiText && aiText.length > 5) {
                appendMessageUI('assistant', aiText);
            } else {
                throw new Error('Empty AI response');
            }
        } catch (err) {
            console.warn('AI API fallback:', err);
            const indicator = document.getElementById('typing-indicator');
            if (indicator) indicator.remove();

            const savedName = localStorage.getItem('saleem_user_name') || 'Friend';
            let reply = `Ahlan ${savedName}! I am Saleem AI. For housing, public transport, or UNHCR residency renewals, feel free to ask!`;
            const lower = prompt.toLowerCase();
            if (lower.includes("metro") || lower.includes("መሬት") || lower.includes("مترو")) {
                reply = `The Cairo Metro has 3 main lines. Single tickets cost 6, 8, 12, or 15 EGP. Ladies-only carriages are located in the center of every train.`;
            } else if (lower.includes("apartment") || lower.includes("rent") || lower.includes("ቤት")) {
                reply = `When renting an apartment in Cairo (e.g. Nasr City, Maadi, Faisal), ensure you obtain a formal written lease contract (Aqd Igar).`;
            } else if (lower.includes("unhcr") || lower.includes("residency")) {
                reply = `UNHCR main registration is located at 56 Central Spine, 6th of October City. Bring your passport, yellow card, and 4 passport photos.`;
            }

            appendMessageUI('assistant', reply);
        }
    }

    if (btnSendChat) btnSendChat.addEventListener('click', handleSendMessage);
    if (chatInput) {
        chatInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') handleSendMessage();
        });
    }

    window.sendQuickQuestion = function(qText) {
        if (chatInput) {
            chatInput.value = qText;
            handleSendMessage();
        }
    };
});
